<?php
/**
 * Created by PhpStorm.
 * User: Jonas
 * Date: 17/10/2016
 * Time: 12:21
 */
header('Location: http://localhost/api/public/home.html');