<?php

/**
 * Created by PhpStorm.
 * User: Jonas
 * Date: 16/10/2016
 * Time: 14:34
 */
require_once __DIR__.'/../core/View.php';
class DailyReportView extends View
{

}