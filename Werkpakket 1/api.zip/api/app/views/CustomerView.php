<?php
/**
 * Created by PhpStorm.
 * User: Jonas
 * Date: 14/10/2016
 * Time: 16:03
 */
require_once __DIR__.'/../core/View.php';
class CustomerView extends View
{
}