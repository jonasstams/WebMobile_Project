<?php
define('DB_HOST', '10.3.1.195');
define('DB_USER', 'jonasuf171_PXL');
define('DB_PASSWORD', 'v904LQ11vM');
define('DB_NAME', 'jonasuf171_API');
